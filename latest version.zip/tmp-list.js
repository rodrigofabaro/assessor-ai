const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

(async () => {
  const students = await prisma.student.findMany();
  const assignments = await prisma.assignment.findMany();
  console.log("STUDENTS:", students);
  console.log("ASSIGNMENTS:", assignments);
  await prisma.$disconnect();
})();
