"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "next/navigation";

type ExtractedPage = {
  id: string;
  pageNumber: number;
  text: string;
  confidence: number;
};

type ExtractionRun = {
  id: string;
  status: "PENDING" | "RUNNING" | "DONE" | "NEEDS_OCR" | "FAILED";
  isScanned: boolean;
  overallConfidence: number | null;
  engineVersion: string;
  startedAt: string;
  finishedAt?: string | null;
  warnings?: any[] | null;
  error?: string | null;
  pages: ExtractedPage[];
};

type Submission = {
  id: string;
  filename: string;
  status: string;
  uploadedAt: string;
  student?: { id: string; fullName: string; email?: string | null; externalRef?: string | null } | null;
  assignment?: {
    id: string;
    unitCode: string;
    assignmentRef?: string | null;
    title: string;
  } | null;
  studentLinkedAt?: string | null;
  studentLinkedBy?: string | null;
  extractionRuns: ExtractionRun[];
  assessments?: Array<{
    id: string;
    createdAt: string;
    overallGrade: string | null;
    annotatedPdfPath: string | null;
  }>;
};

type TriageInfo = {
  unitCode?: string | null;
  assignmentRef?: string | null;
  studentName?: string | null;
  email?: string | null;
  sampleLines?: string[];
  warnings?: string[];
  studentDetection?: {
    detected: boolean;
    linked: boolean;
    source: "text" | "filename" | "email" | null;
  };
  coverage?: {
    hasUnitSpec: boolean;
    hasAssignmentBrief: boolean;
    missing: string[];
  };
};

type StudentSearchResult = {
  id: string;
  fullName: string;
  email?: string | null;
  externalRef?: string | null;
};

function cx(...xs: Array<string | false | null | undefined>) {
  return xs.filter(Boolean).join(" ");
}

function safeDate(s?: string | null) {
  if (!s) return "—";
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString();
}

async function jsonFetch<T>(url: string, opts?: RequestInit): Promise<T> {
  const res = await fetch(url, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as any)?.error || `Request failed (${res.status})`);
  return data as T;
}

function StatusPill({ children }: { children: string }) {
  return (
    <span className="inline-flex items-center rounded-full border border-zinc-200 bg-white px-2.5 py-1 text-xs font-semibold text-zinc-700">
      {children}
    </span>
  );
}

function nextAction(status: string) {
  switch (status) {
    case "UPLOADED":
    case "EXTRACTING":
      return "Extraction running";
    case "EXTRACTED":
      return "Ready to assess";
    case "NEEDS_OCR":
      return "Needs OCR";
    case "ASSESSING":
    case "MARKING":
      return "Assessment running";
    case "DONE":
      return "Upload back to Totara";
    case "FAILED":
      return "Needs attention";
    default:
      return "—";
  }
}

export default function SubmissionDetailPage() {
  const params = useParams<{ submissionId: string }>();
  const submissionId = String(params?.submissionId || "");

  const [submission, setSubmission] = useState<Submission | null>(null);
  const [triageInfo, setTriageInfo] = useState<TriageInfo | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  // Auto-run extraction once for freshly uploaded submissions.
  const autoStartedRef = useRef(false);

  /* ---------- Student linking state ---------- */
  const [studentQuery, setStudentQuery] = useState("");
  const [studentResults, setStudentResults] = useState<StudentSearchResult[]>([]);
  const [selectedStudentId, setSelectedStudentId] = useState("");
  const [newStudentName, setNewStudentName] = useState("");
  const [newStudentEmail, setNewStudentEmail] = useState("");
  const [studentBusy, setStudentBusy] = useState(false);

  /* ---------- Extraction view state ---------- */
  const [activePage, setActivePage] = useState(0);
  const refreshSeq = useRef(0);

  const latestRun = useMemo(() => {
    const runs = submission?.extractionRuns ?? [];
    if (!runs.length) return null;
    return [...runs].sort((a, b) => {
      const at = new Date(a.finishedAt ?? a.startedAt).getTime();
      const bt = new Date(b.finishedAt ?? b.startedAt).getTime();
      return bt - at;
    })[0];
  }, [submission]);

  const pagesSorted = useMemo(
    () => [...(latestRun?.pages ?? [])].sort((a, b) => a.pageNumber - b.pageNumber),
    [latestRun]
  );

  const active = pagesSorted[Math.min(Math.max(activePage, 0), Math.max(pagesSorted.length - 1, 0))];

  const latestAssessment = useMemo(() => {
    const a = submission?.assessments ?? [];
    if (!a.length) return null;
    return a[0];
  }, [submission]);

  const checklist = useMemo(() => {
    const studentLinked = !!submission?.student;
    const assignmentLinked = !!submission?.assignment;
    const extractionComplete = latestRun?.status === "DONE" || latestRun?.status === "NEEDS_OCR";
    const gradeGenerated = !!latestAssessment?.overallGrade;
    const markedPdfGenerated = !!latestAssessment?.annotatedPdfPath;

    // Marked PDF will arrive in Phase 5. Until then, we treat it as optional.
    const readyToUpload = studentLinked && assignmentLinked && extractionComplete && gradeGenerated;

    return {
      studentLinked,
      assignmentLinked,
      extractionComplete,
      gradeGenerated,
      markedPdfGenerated,
      readyToUpload,
    };
  }, [submission, latestRun, latestAssessment]);

  /* =========================
     Data loading
  ========================= */

  async function refresh() {
    if (!submissionId) return;
    const seq = ++refreshSeq.current;
    const data = await jsonFetch<{ submission: Submission }>(
      `/api/submissions/${submissionId}?t=${Date.now()}`,
      { cache: "no-store" }
    );
    if (seq !== refreshSeq.current) return;
    setSubmission(data.submission);
  }

  useEffect(() => {
    if (!submissionId) return;
    refresh().catch((e) => setErr(e?.message || String(e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [submissionId]);

  useEffect(() => {
    if (!submissionId) return;
    if (!submission) return;
    const hasRun = (submission.extractionRuns?.length ?? 0) > 0;
    const isFresh = submission.status === "UPLOADED" && !hasRun;
    if (!isFresh) return;
    if (autoStartedRef.current) return;
    autoStartedRef.current = true;
    runExtraction().catch((e) => setErr(String(e?.message || e)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [submissionId, submission]);

  /* =========================
     Extraction + Triage
  ========================= */

  async function runExtraction() {
    if (!submissionId) return;
    setBusy(true);
    setErr("");
    setMsg("");
    setTriageInfo(null);
    try {
      await jsonFetch(`/api/submissions/${submissionId}/extract`, { method: "POST" });
      const triage = await jsonFetch<{ triage?: TriageInfo; submission?: Submission }>(
        `/api/submissions/${submissionId}/triage`,
        { method: "POST" }
      );
      if (triage.triage) setTriageInfo(triage.triage);
      if (triage.submission) setSubmission(triage.submission);
      await refresh();
      setMsg("Extraction complete.");
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setBusy(false);
    }
  }

  /* =========================
     Student search
  ========================= */

  useEffect(() => {
    let alive = true;
    const q = studentQuery.trim();
    if (q.length < 2) {
      setStudentResults([]);
      return;
    }
    const t = setTimeout(async () => {
      try {
        const res = await jsonFetch<any>(`/api/students?query=${encodeURIComponent(q)}`);
        const list = (Array.isArray(res) ? res : res?.students) as StudentSearchResult[] | undefined;
        if (alive) setStudentResults(Array.isArray(list) ? list : []);
      } catch {
        if (alive) setStudentResults([]);
      }
    }, 250);
    return () => {
      alive = false;
      clearTimeout(t);
    };
  }, [studentQuery]);

  async function linkStudent(studentId: string) {
    if (!studentId) return;
    setStudentBusy(true);
    setErr("");
    setMsg("");
    try {
      const res = await jsonFetch<{ submission: Submission }>(
        `/api/submissions/${submissionId}/link-student`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ studentId, actor: "Rodrigo" }),
        }
      );
      setSubmission(res.submission);
      await refresh();
      setMsg("Student linked.");
    } catch (e: any) {
      setErr(e?.message || "Link failed");
    } finally {
      setStudentBusy(false);
    }
  }

  async function unlinkStudent() {
    setStudentBusy(true);
    setErr("");
    setMsg("");
    try {
      const res = await jsonFetch<{ submission: Submission }>(
        `/api/submissions/${submissionId}/unlink-student`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ actor: "Rodrigo" }),
        }
      );
      setSubmission(res.submission);
      await refresh();
      setMsg("Student unlinked.");
    } catch (e: any) {
      setErr(e?.message || "Unlink failed");
    } finally {
      setStudentBusy(false);
    }
  }

  async function createStudentAndLink() {
    const fullName = newStudentName.trim();
    if (!fullName) return;
    setStudentBusy(true);
    setErr("");
    setMsg("");
    try {
      const res = await jsonFetch<any>(`/api/students`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fullName, email: newStudentEmail.trim() || null }),
      });
      const student = (res?.student ?? res) as StudentSearchResult;
      if (student?.id) await linkStudent(student.id);
      setNewStudentName("");
      setNewStudentEmail("");
    } finally {
      setStudentBusy(false);
    }
  }

  const pdfUrl = submissionId ? `/api/submissions/${submissionId}/file?t=${Date.now()}` : "";

  return (
    <main className="mx-auto max-w-7xl p-6">
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="text-xs font-semibold text-zinc-500">Submissions</div>
          <h1 className="mt-1 text-2xl font-semibold tracking-tight">{submission?.filename || "Submission"}</h1>
          <p className="mt-2 max-w-3xl text-sm text-zinc-600">
            Goal: produce an audit-safe grade + human feedback + a marked PDF you can upload back to Totara.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Link
            href="/submissions"
            className="inline-flex items-center gap-2 rounded-xl border border-zinc-200 bg-white px-4 py-2 text-sm font-semibold hover:bg-zinc-50"
          >
            ← Back
          </Link>
          <button
            type="button"
            onClick={runExtraction}
            disabled={busy || submission?.status === "EXTRACTING"}
            className={cx(
              "inline-flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold shadow-sm",
              busy || submission?.status === "EXTRACTING"
                ? "cursor-not-allowed bg-zinc-300 text-zinc-700"
                : "bg-zinc-900 text-white hover:bg-zinc-800"
            )}
          >
            {busy || submission?.status === "EXTRACTING" ? "Processing…" : "Run extraction"}
          </button>
        </div>
      </div>

      {(err || msg) && (
        <div
          className={cx(
            "mb-4 rounded-xl border p-3 text-sm",
            err ? "border-red-200 bg-red-50 text-red-900" : "border-emerald-200 bg-emerald-50 text-emerald-900"
          )}
        >
          {err || msg}
        </div>
      )}

      <section className="grid gap-4 lg:grid-cols-3">
        {/* LEFT: PDF */}
        <div className="lg:col-span-2">
          <div className="rounded-2xl border border-zinc-200 bg-white shadow-sm">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-200 p-4">
              <div className="flex items-center gap-3">
                <StatusPill>{submission?.status || "—"}</StatusPill>
                <div className="text-sm text-zinc-600">Next action: <span className="font-semibold text-zinc-900">{nextAction(String(submission?.status || ""))}</span></div>
              </div>
              <div className="text-xs text-zinc-500">Uploaded: {safeDate(submission?.uploadedAt)}</div>
            </div>

            <div className="aspect-[4/3] w-full bg-zinc-50">
              {/* PDF render (works for scanned + digital PDFs) */}
              {submissionId ? (
                <iframe
                  title="Submission PDF"
                  src={pdfUrl}
                  className="h-full w-full"
                />
              ) : (
                <div className="flex h-full items-center justify-center text-sm text-zinc-600">Loading…</div>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT: Metadata + extraction */}
        <div className="grid gap-4">
          <div className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-semibold text-zinc-500">Totara upload checklist</div>
                <div className="mt-1 text-sm text-zinc-600">Quick sanity check before you upload results back.</div>
              </div>
              {checklist.readyToUpload ? (
                <span className="inline-flex items-center rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-900">
                  ✓ Ready
                </span>
              ) : (
                <span className="inline-flex items-center rounded-full border border-amber-200 bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-900">
                  In progress
                </span>
              )}
            </div>

            <ul className="mt-3 space-y-2 text-sm">
              <li className="flex items-center justify-between gap-3">
                <span className="text-zinc-700">Student linked</span>
                <span className={cx("font-semibold", checklist.studentLinked ? "text-emerald-700" : "text-zinc-400")}>
                  {checklist.studentLinked ? "Yes" : "No"}
                </span>
              </li>
              <li className="flex items-center justify-between gap-3">
                <span className="text-zinc-700">Assignment linked</span>
                <span className={cx("font-semibold", checklist.assignmentLinked ? "text-emerald-700" : "text-zinc-400")}>
                  {checklist.assignmentLinked ? "Yes" : "No"}
                </span>
              </li>
              <li className="flex items-center justify-between gap-3">
                <span className="text-zinc-700">Extraction complete</span>
                <span className={cx("font-semibold", checklist.extractionComplete ? "text-emerald-700" : "text-zinc-400")}>
                  {checklist.extractionComplete ? "Yes" : "No"}
                </span>
              </li>
              <li className="flex items-center justify-between gap-3">
                <span className="text-zinc-700">Grade generated</span>
                <span className={cx("font-semibold", checklist.gradeGenerated ? "text-emerald-700" : "text-zinc-400")}>
                  {checklist.gradeGenerated ? (latestAssessment?.overallGrade || "Yes") : "No"}
                </span>
              </li>
              <li className="flex items-center justify-between gap-3">
                <span className="text-zinc-700">Marked PDF</span>
                <span className={cx("font-semibold", checklist.markedPdfGenerated ? "text-emerald-700" : "text-zinc-400")}>
                  {checklist.markedPdfGenerated ? "Yes" : "Later"}
                </span>
              </li>
            </ul>

            {!checklist.readyToUpload ? (
              <div className="mt-3 rounded-xl border border-zinc-200 bg-zinc-50 p-3 text-xs text-zinc-600">
                Tip: this panel is deliberately strict about the basics. Marked PDFs will become a required item once Phase 5 lands.
              </div>
            ) : null}
          </div>

          <div className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
            <div className="text-xs font-semibold text-zinc-500">Student</div>
            <div className="mt-1 flex items-start justify-between gap-3">
              <div>
                <div className="text-lg font-semibold text-zinc-900">
                  {submission?.student?.fullName || "Unlinked"}
                </div>
                <div className="mt-1 text-sm text-zinc-600">
                  {[submission?.student?.email, submission?.student?.externalRef].filter(Boolean).join(" · ") || "—"}
                </div>
                {triageInfo?.studentName && !submission?.student?.fullName ? (
                  <div className="mt-2 text-xs text-zinc-500">
                    Detected on cover page: <span className="font-semibold text-zinc-900">{triageInfo.studentName}</span>
                  </div>
                ) : null}
              </div>
              {submission?.student ? (
                <button
                  type="button"
                  onClick={unlinkStudent}
                  disabled={studentBusy}
                  className={cx(
                    "rounded-xl border px-3 py-2 text-sm font-semibold",
                    studentBusy
                      ? "cursor-not-allowed border-zinc-200 bg-zinc-100 text-zinc-500"
                      : "border-zinc-200 bg-white hover:bg-zinc-50"
                  )}
                >
                  Unlink
                </button>
              ) : null}
            </div>

            {!submission?.student ? (
              <div className="mt-4 grid gap-3">
                <div>
                  <div className="text-sm font-semibold">Find existing student</div>
                  <input
                    value={studentQuery}
                    onChange={(e) => setStudentQuery(e.target.value)}
                    placeholder="Search by name, email, AB number…"
                    className="mt-2 h-10 w-full rounded-xl border border-zinc-300 px-3 text-sm"
                  />
                  <div className="mt-2 max-h-44 overflow-auto rounded-xl border border-zinc-200">
                    {studentResults.length === 0 ? (
                      <div className="p-3 text-sm text-zinc-600">No results yet.</div>
                    ) : (
                      <div className="divide-y divide-zinc-100">
                        {studentResults.slice(0, 10).map((st) => (
                          <label key={st.id} className="flex cursor-pointer items-start gap-3 p-3">
                            <input
                              type="radio"
                              name="student"
                              className="mt-1"
                              checked={selectedStudentId === st.id}
                              onChange={() => setSelectedStudentId(st.id)}
                            />
                            <div>
                              <div className="text-sm font-semibold text-zinc-900">{st.fullName}</div>
                              <div className="mt-0.5 text-xs text-zinc-600">{[st.email, st.externalRef].filter(Boolean).join(" · ") || "—"}</div>
                            </div>
                          </label>
                        ))}
                      </div>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={() => linkStudent(selectedStudentId)}
                    disabled={!selectedStudentId || studentBusy}
                    className={cx(
                      "mt-2 inline-flex w-full items-center justify-center rounded-xl px-4 py-2 text-sm font-semibold",
                      !selectedStudentId || studentBusy
                        ? "cursor-not-allowed bg-zinc-200 text-zinc-600"
                        : "bg-zinc-900 text-white hover:bg-zinc-800"
                    )}
                  >
                    Link selected
                  </button>
                </div>

                <div className="rounded-xl border border-zinc-200 bg-zinc-50 p-3">
                  <div className="text-sm font-semibold text-zinc-900">Quick create</div>
                  <div className="mt-2 grid gap-2">
                    <input
                      value={newStudentName}
                      onChange={(e) => setNewStudentName(e.target.value)}
                      placeholder="New student full name"
                      className="h-10 w-full rounded-xl border border-zinc-300 px-3 text-sm"
                    />
                    <input
                      value={newStudentEmail}
                      onChange={(e) => setNewStudentEmail(e.target.value)}
                      placeholder="Email (optional)"
                      className="h-10 w-full rounded-xl border border-zinc-300 px-3 text-sm"
                    />
                    <button
                      type="button"
                      onClick={createStudentAndLink}
                      disabled={!newStudentName.trim() || studentBusy}
                      className={cx(
                        "inline-flex items-center justify-center rounded-xl px-4 py-2 text-sm font-semibold",
                        !newStudentName.trim() || studentBusy
                          ? "cursor-not-allowed bg-zinc-200 text-zinc-600"
                          : "bg-white text-zinc-900 hover:bg-zinc-100 border border-zinc-200"
                      )}
                    >
                      Create & link
                    </button>
                  </div>
                </div>
              </div>
            ) : null}

            {submission?.studentLinkedAt ? (
              <div className="mt-3 text-xs text-zinc-500">
                Linked: {safeDate(submission.studentLinkedAt)}{submission.studentLinkedBy ? ` · by ${submission.studentLinkedBy}` : ""}
              </div>
            ) : null}
          </div>

          <div className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
            <div className="text-xs font-semibold text-zinc-500">Assignment</div>
            <div className="mt-1 text-lg font-semibold text-zinc-900">
              {submission?.assignment ? `${submission.assignment.unitCode} ${submission.assignment.assignmentRef || ""}`.trim() : "Unassigned"}
            </div>
            <div className="mt-1 text-sm text-zinc-600">{submission?.assignment?.title || "—"}</div>

            {triageInfo?.coverage?.missing?.length ? (
              <div className="mt-3 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
                <div className="text-xs font-semibold uppercase tracking-wide">Reference coverage</div>
                <div className="mt-2">Missing: {triageInfo.coverage.missing.join(", ")}</div>
              </div>
            ) : null}
          </div>

          <div className="rounded-2xl border border-zinc-200 bg-white shadow-sm">
            <div className="border-b border-zinc-200 p-4">
              <div className="flex items-center justify-between gap-3">
                <div>
                  <div className="text-xs font-semibold text-zinc-500">Extraction</div>
                  <div className="mt-1 text-sm font-semibold text-zinc-900">
                    {latestRun ? `Latest run · ${latestRun.engineVersion}` : "Not run yet"}
                  </div>
                </div>
                {latestRun ? (
                  <div className="text-xs text-zinc-500">
                    {latestRun.status} · Confidence {Math.round((latestRun.overallConfidence || 0) * 100)}%
                  </div>
                ) : null}
              </div>
            </div>

            <div className="p-4">
              {!latestRun ? (
                <div className="text-sm text-zinc-600">
                  No extraction yet. Click <span className="font-semibold">Run extraction</span> to generate readable text for grading.
                </div>
              ) : (
                <div className="grid gap-3">
                  {latestRun.error ? (
                    <div className="rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-900">
                      {latestRun.error}
                    </div>
                  ) : null}

                  {!!triageInfo?.warnings?.length ? (
                    <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
                      <div className="text-xs font-semibold uppercase tracking-wide">Warnings</div>
                      <ul className="mt-2 list-disc space-y-1 pl-5">
                        {triageInfo.warnings.slice(0, 5).map((w, i) => (
                          <li key={i}>{w}</li>
                        ))}
                      </ul>
                    </div>
                  ) : null}

                  <div className="flex flex-wrap items-center gap-2">
                    <div className="text-xs font-semibold text-zinc-500">Page</div>
                    <select
                      value={activePage}
                      onChange={(e) => setActivePage(Number(e.target.value))}
                      className="h-9 rounded-xl border border-zinc-300 bg-white px-3 text-sm"
                    >
                      {pagesSorted.map((p, idx) => (
                        <option key={p.id} value={idx}>
                          {p.pageNumber} (conf {Math.round((p.confidence || 0) * 100)}%)
                        </option>
                      ))}
                    </select>
                    <div className="ml-auto text-xs text-zinc-500">Started: {safeDate(latestRun.startedAt)}</div>
                  </div>

                  <div className="max-h-[42vh] overflow-auto rounded-xl border border-zinc-200 bg-zinc-50 p-3">
                    <div className="whitespace-pre-wrap font-mono text-xs text-zinc-800">
                      {active?.text?.trim() ? active.text : "(No meaningful text on this page yet)"}
                    </div>
                  </div>

                  <div className="text-xs text-zinc-500">
                    Tip: scanned/handwritten pages may show low text. Those will become "NEEDS_OCR" later when we add vision.
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="rounded-2xl border border-zinc-200 bg-white p-4 shadow-sm">
            <div className="text-sm font-semibold">Totara upload checklist</div>
            <div className="mt-2 text-sm text-zinc-600">
              This will light up once grading is enabled.
            </div>
            <div className="mt-3 grid gap-2 text-sm">
              <label className="flex items-center gap-2 text-zinc-700">
                <input type="checkbox" className="h-4 w-4 rounded border-zinc-300" disabled /> Marked PDF ready
              </label>
              <label className="flex items-center gap-2 text-zinc-700">
                <input type="checkbox" className="h-4 w-4 rounded border-zinc-300" disabled /> Feedback ready
              </label>
              <label className="flex items-center gap-2 text-zinc-700">
                <input type="checkbox" className="h-4 w-4 rounded border-zinc-300" disabled /> Overall grade ready
              </label>
            </div>
            <div className="mt-3 text-xs text-zinc-500">We’ll store timestamps + model/prompt versions so you can defend every decision.</div>
          </div>
        </div>
      </section>
    </main>
  );
}
