// app/admin/specs/page.tsx
import SpecsAdminPage from "./SpecsAdminPage";

export default function Page() {
  return <SpecsAdminPage />;
}
