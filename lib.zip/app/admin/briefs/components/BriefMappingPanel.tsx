"use client";

import type { Criterion, Unit } from "../../reference/reference.logic";

export default function BriefMappingPanel({
  draft,
  units,
  briefUnitId,
  setBriefUnitId,
  criteria,
  mapSelected,
  setMapSelected,
  assignmentCodeInput,
  setAssignmentCodeInput,
}: {
  draft: any;
  units: Unit[];
  briefUnitId: string;
  setBriefUnitId: (id: string) => void;
  criteria: Criterion[];
  mapSelected: Record<string, boolean>;
  setMapSelected: (x: Record<string, boolean>) => void;
  assignmentCodeInput: string;
  setAssignmentCodeInput: (v: string) => void;
}) {
  const kind = draft?.kind || "";
  const codes: string[] = (draft?.detectedCriterionCodes || []).map((x: string) => String(x).toUpperCase());
  const unitGuess = draft?.unitCodeGuess ? String(draft.unitCodeGuess) : "";

  return (
    <div className="rounded-2xl border border-zinc-200 bg-white p-4">
      <div className="text-xs text-zinc-600">Mapping</div>

      {kind !== "BRIEF" ? (
        <p className="mt-2 text-sm text-zinc-700">No BRIEF draft extracted yet. Click Extract.</p>
      ) : (
        <>
          <div className="mt-2 grid gap-4 md:grid-cols-2">
            <div className="min-w-0">
              <div className="text-xs text-zinc-600">Assignment</div>
              <div className="mt-1 font-semibold text-zinc-900 break-words">
                {draft.assignmentCode || "(missing)"} — {draft.title || "(title not detected)"}
              </div>

              <div className="mt-3">
                <div className="mb-1 text-xs text-zinc-600">Assignment code (required to lock)</div>
                <input
                  value={assignmentCodeInput}
                  onChange={(e: any) => setAssignmentCodeInput(e.target.value.toUpperCase())}
                  placeholder="e.g. A1"
                  className="h-10 w-36 rounded-xl border border-zinc-300 px-3 text-sm"
                />
              </div>

              {draft.assignmentNumber ? (
                <div className="mt-2 text-xs text-zinc-600">
                  Assignment {draft.assignmentNumber} of {draft.totalAssignments || "?"}
                </div>
              ) : null}
            </div>

            <div>
              <div className="text-xs text-zinc-600">Detected unit</div>
              <div className="mt-1 font-semibold text-zinc-900">{unitGuess ? `Unit ${unitGuess}` : "(not detected)"}</div>
              {draft.aiasLevel ? <div className="mt-1 text-xs text-zinc-600">AIAS Level {draft.aiasLevel}</div> : null}
            </div>
          </div>

          <div className="mt-4 border-t border-zinc-200 pt-4">
            <label className="text-xs text-zinc-600">Link this brief to a unit</label>
            <div className="mt-1">
              <select
                value={briefUnitId}
                onChange={(e: any) => setBriefUnitId(e.target.value)}
                className="h-10 w-full rounded-xl border border-zinc-300 bg-white px-3 text-sm"
              >
                <option value="">(select unit...)</option>
                {units
                  .filter((u: any) => u.status === "LOCKED" && !(u as any)?.sourceMeta?.archived)
                  .map((u: any) => (
                    <option key={u.id} value={u.id}>
                      {u.unitCode} — {u.unitTitle}
                      {(() => {
                        const issue = (u as any)?.specIssue || (u as any)?.specDocument?.sourceMeta?.specIssue;
                        return issue ? ` (${issue})` : "";
                      })()}
                    </option>
                  ))}
              </select>
            </div>
            <p className="mt-2 text-xs text-zinc-500">Only ACTIVE (non-archived) locked specs are shown here.</p>
          </div>

          <div className="mt-4 border-t border-zinc-200 pt-4">
            <div className="font-semibold text-zinc-900">Criteria mapping</div>
            <p className="mt-1 text-sm text-zinc-700 break-words">
              Detected codes: <span className="font-semibold">{codes.length ? codes.join(", ") : "(none)"}</span>
            </p>

            {!briefUnitId ? (
              <p className="mt-2 text-sm text-zinc-600">Select a unit to view criteria and confirm mapping.</p>
            ) : criteria.length === 0 ? (
              <p className="mt-2 text-sm text-zinc-600">No criteria found for this unit (spec not extracted/locked?).</p>
            ) : (
              <div className="mt-3 grid gap-2">
                {criteria.map((c: any) => {
                  const checked = !!mapSelected[c.id];
                  const suggested = codes.includes(String(c.acCode || "").toUpperCase());
                  return (
                    <label
                      key={c.id}
                      className={
                        "flex items-start gap-3 rounded-xl border p-3 text-sm " +
                        (checked ? "border-zinc-900 bg-zinc-900 text-white" : "border-zinc-200 bg-white hover:bg-zinc-50")
                      }
                      title={suggested ? "Detected in brief text" : ""}
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={(e: any) => {
                          const next = { ...mapSelected, [c.id]: e.target.checked };
                          if (!e.target.checked) delete next[c.id];
                          setMapSelected(next);
                        }}
                        className="mt-1"
                      />
                      <div className="min-w-0">
                        <div className={"inline-flex items-center gap-2 " + (checked ? "text-white" : "text-zinc-900")}>
                          <span
                            className={
                              "rounded-lg border px-2 py-0.5 text-xs font-bold " +
                              (checked ? "border-white/30 bg-white/10" : "border-zinc-200 bg-zinc-50")
                            }
                          >
                            {c.acCode}
                          </span>
                          <span className={"text-xs " + (checked ? "text-zinc-200" : "text-zinc-600")}>{c.gradeBand}</span>
                          {suggested ? <span className={"text-xs font-semibold " + (checked ? "text-emerald-200" : "text-emerald-700")}>Detected</span> : null}
                        </div>
                        <div className={"mt-1 text-xs leading-relaxed " + (checked ? "text-zinc-200" : "text-zinc-700")}>
                          {c.description}
                        </div>
                      </div>
                    </label>
                  );
                })}
              </div>
            )}

            <p className="mt-3 text-xs text-zinc-500">
              Lock will store the selected criteria mapping and bind this brief PDF to the chosen locked unit spec.
            </p>
          </div>
        </>
      )}
    </div>
  );
}
