"use client";

import type { Criterion, ReferenceDocument, Unit } from "../../reference/reference.logic";
import { Meta } from "./ui";
import BriefMappingPanel from "./BriefMappingPanel";

export default function BriefReviewCard({ rx }: { rx: any }) {
  const doc = rx.selectedDoc as ReferenceDocument | null;
  const draft: any = doc?.extractedJson || null;

  const canExtract = !!doc && !rx.busy;
  const canLock = !!doc && !rx.busy;

  const header = (draft && draft.kind === "BRIEF" ? draft.header || {} : {}) as any;

  return (
    <section className="rounded-2xl border border-zinc-200 bg-white shadow-sm min-w-0 overflow-hidden">
      <div className="border-b border-zinc-200 p-4">
        <div className="text-sm font-semibold">Review</div>
        <div className="mt-1 text-xs text-zinc-600">BRIEF-only review: header fields + mapping + lock.</div>
      </div>

      {!doc ? (
        <div className="p-4 text-sm text-zinc-600">Select a BRIEF PDF from the inbox to review it.</div>
      ) : (
        <div className="p-4 grid gap-4">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Meta label="Type" value={doc.type} />
            <Meta label="Uploaded" value={new Date(doc.uploadedAt).toLocaleString()} />
            <Meta label="Status" value={doc.status} />
            <Meta label="Locked at" value={doc.lockedAt ? new Date(doc.lockedAt).toLocaleString() : ""} />
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              disabled={!canExtract}
              onClick={rx.extractSelected}
              className={
                "h-10 rounded-xl px-4 text-sm font-semibold " +
                (!canExtract ? "bg-zinc-200 text-zinc-600 cursor-not-allowed" : "bg-zinc-900 text-white hover:bg-zinc-800")
              }
            >
              Extract
            </button>

            <button
              type="button"
              disabled={!canExtract}
              onClick={rx.reextractSelected}
              className={
                "h-10 rounded-xl border px-4 text-sm font-semibold " +
                (!canExtract ? "border-zinc-200 bg-white text-zinc-400 cursor-not-allowed" : "border-zinc-200 bg-white text-zinc-900 hover:bg-zinc-50")
              }
            >
              Re-extract
            </button>

            <button
              type="button"
              disabled={!canLock}
              onClick={rx.lockSelected}
              className={
                "h-10 rounded-xl border px-4 text-sm font-semibold " +
                (!canLock ? "border-zinc-200 bg-white text-zinc-400 cursor-not-allowed" : "border-zinc-900 bg-zinc-900 text-white hover:bg-zinc-800")
              }
            >
              Lock
            </button>

            <a
              href={`/api/reference-documents/${doc.id}/file`}
              target="_blank"
              rel="noreferrer"
              className="h-10 inline-flex items-center rounded-xl border border-zinc-200 bg-white px-4 text-sm font-semibold text-zinc-900 hover:bg-zinc-50"
            >
              PDF preview
            </a>
          </div>

          <div className="rounded-2xl border border-zinc-200 bg-white p-4">
            <div className="text-xs text-zinc-600">Header snapshot (extracted)</div>
            <div className="mt-2 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              <Meta label="Academic year" value={header.academicYear || ""} />
              <Meta label="IV name" value={header.internalVerifier || ""} />
              <Meta label="IV date" value={header.verificationDate || ""} />
              <Meta label="Issue date" value={header.issueDate || ""} />
              <Meta label="Final submission" value={header.finalSubmissionDate || ""} />
            </div>
            <p className="mt-2 text-xs text-zinc-500">These are stored for audit. If the PDF changes next year, upload a new version and re-lock.</p>
          </div>

          <BriefMappingPanel
            draft={draft}
            units={rx.units as unknown as Unit[]}
            briefUnitId={rx.briefUnitId}
            setBriefUnitId={rx.setBriefUnitId}
            criteria={rx.criteriaForSelectedUnit as unknown as Criterion[]}
            mapSelected={rx.mapSelected}
            setMapSelected={rx.setMapSelected}
            assignmentCodeInput={rx.assignmentCodeInput}
            setAssignmentCodeInput={rx.setAssignmentCodeInput}
          />

          <details className="rounded-2xl border border-zinc-200 bg-white p-4">
            <summary className="cursor-pointer text-sm font-semibold text-zinc-900">Raw extracted JSON (advanced)</summary>
            <pre className="mt-3 max-h-[360px] overflow-auto rounded-xl border border-zinc-200 bg-zinc-50 p-3 text-xs">
              {JSON.stringify(draft, null, 2)}
            </pre>
          </details>
        </div>
      )}
    </section>
  );
}
