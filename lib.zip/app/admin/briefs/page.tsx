// app/admin/briefs/page.tsx
import BriefsAdminPage from "./BriefsAdminPage";

export default function Page() {
  return <BriefsAdminPage />;
}
