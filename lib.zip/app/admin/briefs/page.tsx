import AdminBriefsPage from "./briefs.page";

export default function Page() {
  return <AdminBriefsPage />;
}
